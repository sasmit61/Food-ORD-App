package com.example.foodorderback.model;

public enum Status {
	ORDERED, DELIVERY, PREPARATION
}
